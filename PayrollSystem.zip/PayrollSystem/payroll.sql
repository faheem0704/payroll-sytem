-- MySQL dump 10.13  Distrib 8.0.35, for Win64 (x86_64)
--
-- Host: localhost    Database: payroll
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendence`
--

DROP TABLE IF EXISTS `attendence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendence` (
  `eid` varchar(20) DEFAULT NULL,
  `first_half` varchar(20) DEFAULT NULL,
  `second_half` varchar(20) DEFAULT NULL,
  `date` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendence`
--

LOCK TABLES `attendence` WRITE;
/*!40000 ALTER TABLE `attendence` DISABLE KEYS */;
INSERT INTO `attendence` VALUES ('1001','absent','present','Mon Nov 13 14:40:19 IST 2023'),('1001','present','absent','Mon Nov 13 18:46:34 IST 2023');
/*!40000 ALTER TABLE `attendence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES ('admin','admin');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_employee`
--

DROP TABLE IF EXISTS `new_employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `new_employee` (
  `eid` varchar(100) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_employee`
--

LOCK TABLES `new_employee` WRITE;
/*!40000 ALTER TABLE `new_employee` DISABLE KEYS */;
INSERT INTO `new_employee` VALUES ('1001','faheem','male','sivapuram','kerala','kannur','muhammedf0704@gmail.com','8385050504'),('1002','nihan','male','pattom','kerala','trivandrum','nihannavas@gmail.com','9400330966'),('1003','veena maheshwari','female','pattom','kerala','trivandrum','veena@gmail.com','8078396284'),('1004','thahzeen','male','mouvery','kerala','kuthuparamba','thahzi123@gmail.com','8086646555'),('1005','lahan','male','thalassery','kerala','thalassery','lahanlallu@gmail.com','8089014542'),('1006','anushka','female','azhikode','kerala','kannur','anushka@gmail.com','9497723240'),('1007','gauthem','male','payyoli','kerala','kozhikode','gauthem@gmail.com','1254768987'),('1008','maneesha','female','thalassery','kerala','kannur','maneesha@gmail.com','8486060605');
/*!40000 ALTER TABLE `new_employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salery`
--

DROP TABLE IF EXISTS `salery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salery` (
  `eid` varchar(100) DEFAULT NULL,
  `hra` varchar(100) DEFAULT NULL,
  `da` varchar(100) DEFAULT NULL,
  `mid` varchar(100) DEFAULT NULL,
  `pf` varchar(100) DEFAULT NULL,
  `basic` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salery`
--

LOCK TABLES `salery` WRITE;
/*!40000 ALTER TABLE `salery` DISABLE KEYS */;
INSERT INTO `salery` VALUES ('1001','50.0','24.0','10.0','2550.0','20000.0'),('1005','40','19','20','2500','30000'),('1002','30.0','12.0','25.0','2500.0','15000.0'),('1008','20000.0','0.0','1700.0','2000.0','40000.0');
/*!40000 ALTER TABLE `salery` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-13 19:21:42
