package payroll_project;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.sql.*;

public class generate_paySlip extends JFrame implements ActionListener {
    JButton printButton, saveAsPNGButton; // Added button for saving as PNG
    JLabel l1, l2, l3, l4, l5, l6;
    JTextArea ta;
    Choice ch;
    JPanel p1;
    Font f;

    public generate_paySlip() {
        super("Generate Pay Slip");
        setSize(500, 500);
        setLocation(100, 100);
        setResizable(false);

        f = new Font("Arial", Font.BOLD, 14);

        l2 = new JLabel("Employee id");

        l2.setFont(f);
        ch = new Choice();
        try 
        {
            ConnectionClass obj = new ConnectionClass();
            String q = "select * from new_employee";
            ResultSet rest = obj.stm.executeQuery(q);
            while (rest.next()) {
                ch.add(rest.getString("eid"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        printButton = new JButton("Print");
        printButton.setBackground(Color.BLACK);
        printButton.setForeground(Color.WHITE);
        printButton.addActionListener(this);
        printButton.setFont(f);

        saveAsPNGButton = new JButton("Save as PNG");
        saveAsPNGButton.setBackground(Color.BLACK);
        saveAsPNGButton.setForeground(Color.WHITE);
        saveAsPNGButton.addActionListener(this);
        saveAsPNGButton.setFont(f);

        ta = new JTextArea();
        JScrollPane sp = new JScrollPane(ta);
        ta.setEditable(false);
        ta.setFont(f);

        p1 = new JPanel();
        p1.setLayout(new GridLayout(1, 4, 10, 10)); // Increased columns for the new button
        p1.add(l2);
        p1.add(ch);
        p1.add(printButton);
        p1.add(saveAsPNGButton);

        setLayout(new BorderLayout());
        add(sp, BorderLayout.CENTER);
        add(p1, BorderLayout.SOUTH);
    }

    public void actionPerformed(ActionEvent e) {
    if (e.getSource() == printButton) {
        generatePayslip();
    } else if (e.getSource() == saveAsPNGButton) {
        saveAsPNG(); // Call the method to save payslip as PNG
    }
}

private void generatePayslip() {
    ta.setText("----------PAY SLIP----------");
    try {
        ConnectionClass obj1 = new ConnectionClass();
        int id = Integer.parseInt(ch.getSelectedItem());
        String q1 = "select * from new_employee where eid='" + id + "'";
        ResultSet rest1 = obj1.stm.executeQuery(q1);
        while (rest1.next()) {
            ta.append("\n\nEmployee id: " + Integer.parseInt(rest1.getString("eid")));
            ta.append("\nEmployee name: " + rest1.getString("name"));
            ta.append("\n-------------------------------------\n\n");
        }
        String q2 = "select * from salery where eid='" + id + "'";
        ResultSet rest2 = obj1.stm.executeQuery(q2);
        while (rest2.next()) {
            ta.append("\nHRA : " + Float.parseFloat(rest2.getString("hra")));
            ta.append("\nDA : " + Float.parseFloat(rest2.getString("da")));
            ta.append("\nMED : " + Float.parseFloat(rest2.getString("mid")));
            ta.append("\nPF : " + Float.parseFloat(rest2.getString("pf")));
            ta.append("\nBasic Salary : " + Float.parseFloat(rest2.getString("basic")));
            ta.append("\n-----------------------------------\n\n");
            float gross_salary = Float.parseFloat(rest2.getString("hra"))
                    + Float.parseFloat(rest2.getString("da")) + Float.parseFloat(rest2.getString("mid"))
                    + Float.parseFloat(rest2.getString("pf")) + Float.parseFloat(rest2.getString("basic"));
            double tax = (gross_salary * 2.1) / 100;
            ta.append("\nGross Salary :" + gross_salary);
            ta.append("\nTotal :" + gross_salary);
            ta.append("\nTax 2.1% of salary :" + tax);
        }
    } catch (Exception exx) {
        exx.printStackTrace();
    }
}

private void saveAsPNG() {
    try {
        BufferedImage image = new BufferedImage(ta.getWidth(), ta.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics g = image.getGraphics();
        ta.printAll(g);
        g.dispose();

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Specify a file to save");
        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            ImageIO.write(image, "png", fileToSave);
            JOptionPane.showMessageDialog(this, "Payslip saved as PNG!");
        }
    } 
    catch (IOException ex)
    {
        ex.printStackTrace();
    }
}
    public static void main(String args[]) 
    {
        SwingUtilities.invokeLater(() -> new generate_paySlip().setVisible(true));
    }
}
